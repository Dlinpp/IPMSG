# qipmsg
QT IPMSG Client - Just a software for QT Study.

I Tested it on Linux/Windows.

Features:
1. User List
2. Send/Receive Text Message.
3. Send/Receive Files.
4. English/Chinese UI.
5. IP Address Range settings support.
6. Support Change user information.



