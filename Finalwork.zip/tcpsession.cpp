#include "ipmsgtcpsession.h"

//File Send
//Command 200020
//version:pkt_seq:username:hostname:command:
//1_iptux 0.7.5:47:pacino:mint-pacino:2097184:.10000:before_edit.png:178f1:5be106fb:1:..

IpMsgTcpSession::IpMsgTcpSession(QObject *parent)
    : QObject(parent)
{}
