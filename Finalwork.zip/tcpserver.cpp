#include "ipmsgtcpserver.h"

IpMsgTcpServer::IpMsgTcpServer() {}
